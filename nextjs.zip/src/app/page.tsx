import InputDesign from "@/components/AnimatedDesign";
import LogoCarousel from "@/components/Banner";
import Features from "@/components/Features";
import Footer from "@/components/footer";
import HeroSection from "@/components/Hero";
import { Navigation } from "@/components/Navbar";
import FeaturesGrid from "@/components/PowerFullFeatures";
import CallToActionSection from "@/components/ReadyToTransform";
import SteveAISection from "@/components/SmarterSupport";
import TestimonialsSection from "@/components/Testimonial";
import ChallengesSection from "@/components/WhyChooseUs";
import WhyPumaProSection from "@/components/WhyPumaPro";

export default function Home() {
  return (
    <div className="overflow-hidden">
      <div className="border border-red-500">
        <Navigation />
      </div>
      <div className="border border-orange-500">
        <HeroSection />
      </div>
      {/* <div className="border border-yellow-500">
        <InputDesign />
      </div> */}
      <div className="border border-green-500">
        <LogoCarousel />
      </div>
      <div className="border border-teal-500">
       <Features></Features>
      </div>
      <div className="border border-blue-500">
        <ChallengesSection />
      </div>
      <div className="border border-indigo-500">
        <FeaturesGrid />
      </div>
      <div className="border border-purple-500">
        <SteveAISection />
      </div>
      <div className="border border-pink-500">
        <WhyPumaProSection />
      </div>
      <div className="border border-gray-500">
        <TestimonialsSection />
      </div>
      <div className="border border-black">
        <CallToActionSection />
      </div>
      <div className="border border-stone-500">
        <Footer />
      </div>
    </div>
  );
}
